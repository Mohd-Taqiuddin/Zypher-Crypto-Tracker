// backend/server.ts
import "jsr:@std/dotenv/load";

import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import {
  AnthropicModelProvider,
  ZypherAgent,
} from "@corespeed/zypher";
import { eachValueFrom } from "npm:rxjs-for-await";

// env helper
function getRequiredEnv(name: string): string {
  const value = Deno.env.get(name);
  if (!value) throw new Error(`Environment variable ${name} is not set`);
  return value;
}

// system prompt
const baseInstructions = `
You are a crypto analysis agent. The frontend will send you a token
symbol like BTC, ETH, or AVAX.

Your job:
1. Describe the asset's typical narrative or use case.
2. Give 3 short bullet points about what a short-term trader should watch.
3. End with: "Not financial advice."

Keep the answer under 180 words.
`;

// --- CREATE ZYPHER AGENT (simple version) ---
const zypher = new ZypherAgent(
  new AnthropicModelProvider({
    apiKey: getRequiredEnv("ANTHROPIC_API_KEY"),
  }),
  {
    customInstructions: baseInstructions,
  }
);

// CORS
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

// --- RUN A SINGLE CRYPTO TASK ---
async function runCryptoTask(symbol: string): Promise<string> {
  const cleaned = symbol.trim().toUpperCase() || "BTC";

  const userPrompt = `
Give me a concise crypto analysis for ${cleaned}.
`;

  // reset agent memory for fresh request
  zypher.clearMessages();

  // start task (returns Observable)
  const event$ = zypher.runTask(userPrompt, "claude-sonnet-4-20250514");

  let text = "";
  const rawEvents: string[] = [];

  // stream Zypher events
  for await (const event of eachValueFrom(event$)) {
    rawEvents.push(JSON.stringify(event));

    const e: any = event;

    // text delta
    if (e.delta?.text) {
      text += e.delta.text;
    }

    // final assistant message
    if (e.message?.role === "assistant") {
      const c = e.message.content;
      if (typeof c === "string") text += c;
      if (Array.isArray(c))
        for (const part of c)
          if (typeof part === "string") text += part;
          else if (typeof part?.text === "string") text += part.text;
    }
  }

  if (text.trim().length > 0) return text.trim();

  // fallback so frontend never shows "no response"
  return rawEvents.join("\n");
}

// --- HTTP SERVER ---
serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: cors });
  }

  const url = new URL(req.url);

  if (req.method === "POST" && url.pathname === "/api/crypto") {
    try {
      const body = await req.json();
      const symbol = body.symbol || "BTC";
      const analysis = await runCryptoTask(symbol);

      return new Response(
        JSON.stringify({ symbol, analysis }),
        { headers: { "Content-Type": "application/json", ...cors } }
      );
    } catch (err) {
      console.error(err);
      return new Response(
        JSON.stringify({ error: err.message }),
        {
          status: 500,
          headers: { "Content-Type": "application/json", ...cors },
        }
      );
    }
  }

  return new Response("Not found", { status: 404, headers: cors });
});
